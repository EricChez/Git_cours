export class Bird {
    // initialise class parameters with a constructor
    /*public*/ constructor(race, weight, plumage, span, canFly) {
        this.race = race;
        this.weight = weight;
        this.plumage = plumage;
        this.span = span;
        this.canFly = canFly;
    }
    setRace(value) {
        this.race = value;
    }
    setWeight(value) {
        this.weight = value;
    }
    setPlumage(value) {
        this.plumage = value;
    }
    setSpan(value) {
        this.span = value;
    }
    setCanFly(value) {
        this.canFly = value;
    }
    getRace() {
        return this.race;
    }
    getWeight() {
        return this.weight;
    }
    getPlumage() {
        return this.plumage;
    }
    getSpan() {
        return this.span;
    }
    getCanFly() {
        return this.canFly;
    }
}
