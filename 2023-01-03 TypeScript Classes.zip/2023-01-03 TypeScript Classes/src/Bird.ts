export class Bird {
    // present class parameters
    private race: string;
    private weight: number;
    private plumage: string[];
    private span: number;
    private canFly: boolean;

    // initialise class parameters with a constructor
    /*public*/ constructor(race: string, weight: number, plumage: string[], span: number, canFly: boolean) { // if we don't indicate public, typescript considers it as public
        this.race = race;
        this.weight = weight;
        this.plumage = plumage;
        this.span = span;
        this.canFly = canFly
    }

    setRace(value: string) {
        this.race = value;
    }
    setWeight(value: number) {
        this.weight = value;
    }
    setPlumage(value: string[]) {
        this.plumage = value;
    }
    setSpan(value: number) {
        this.span = value;
    }
    setCanFly(value: boolean) {
        this.canFly = value;
    }

    getRace() {
        return this.race;
    }
    getWeight() {
        return this.weight;
    }
    getPlumage() {
        return this.plumage;
    }
    getSpan() {
        return this.span;
    }
    getCanFly() {
        return this.canFly;
    }
}