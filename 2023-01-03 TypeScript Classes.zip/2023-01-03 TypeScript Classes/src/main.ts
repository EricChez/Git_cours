import {Bird} from './Bird.js';
let ostrich = new Bird('Ostrich', 80, ['white', 'grey', 'black'], 2, false);
console.log(ostrich);

ostrich.setWeight(90);
console.log(ostrich);
//console.log(ostrich.canFly); // no access to private properties, and we should use setters and getters, but the console.log() will still print it